package com.app.myvehicle.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.app.myvehicle.R;
import com.app.myvehicle.models.LogEntry;
import com.app.myvehicle.utils.DBManager;
import com.app.myvehicle.utils.Global;
import com.app.myvehicle.utils.VehicleType;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

/**
 * LogList fragment , shows list of certain type of vehicle's log entry info
 */

public class LogListFragment extends Fragment {

    VehicleType type;
    ListView listView;

    String BUTTON_TITLE[] = new String[]{"RETURN TO CAR", "RETURN TO 5T TRUCK", "RETURN TO 10T TRUCK", "RETURN TO TIPPER", "RETURN TO ARTICULATED"};

    //click listener for return button
    View.OnClickListener clickListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View view) {
            LogListFragment.this.getFragmentManager().popBackStack();
        }
    };

    public LogListFragment()
    {

    }

    public LogListFragment(VehicleType type)
    {
        this.type = type;
    }

    public void loadList()  //load data from db & interal data object and set them to the listview
    {

        //load data from db
        DBManager db = new DBManager(this.getActivity());
        ArrayList<LogEntry> entryList = db.getAllLogEntries(type);

        ArrayList<String> values = new ArrayList<String>();

        for(int index = 0 ; index < entryList.size(); index++)
        {
            LogEntry entry = entryList.get(index);
            String text = entry.driverName + " " + entry.rego + "\n" + entry.startTime + "\n" + entry.firstBreakTime + "\n" + entry.secondBreakTime + "\n" + entry.endTime;

            values.add(text);
        }

        //load data from internal data object

        entryList = Global.getInstance().logEntryList;

        for(int index = 0 ; index < entryList.size(); index++)
        {
            LogEntry entry = entryList.get(index);

            if(entry.vehicleType == type) {

                String text = entry.driverName + " " + entry.rego + "\n" + entry.startTime + "\n" + entry.firstBreakTime + "\n" +
                         entry.secondBreakTime + "\n" + entry.endTime;

                values.add(text);
            }
        }

        //set adapter to the listview

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_list_item_1, values);
        listView.setAdapter(adapter);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_loglist, container , false);

        //init
        listView = (ListView)view.findViewById(R.id.listview);
        Button returnButton = (Button)view.findViewById(R.id.button_return);
        returnButton.setOnClickListener(clickListener);
        returnButton.setText(BUTTON_TITLE[type.getValue()]);

        //load list
        loadList();

        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
