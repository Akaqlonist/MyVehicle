package com.app.myvehicle;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.app.myvehicle.fragments.HomeFragment;
import com.app.myvehicle.fragments.ProfileFragment;
import com.app.myvehicle.models.LogEntry;
import com.app.myvehicle.utils.DBManager;
import com.app.myvehicle.utils.Global;
import com.app.myvehicle.utils.VehicleType;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private String SEND_ALERT_MESSAGE = "Are you sure? This will delete all entries";
    private String BACK_ALERT_MESSAGE = "Save entries to DB first?";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //show home screen
        getSupportFragmentManager().beginTransaction().add(R.id.fragment_container, new HomeFragment()).commit();

        //request location access permission
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        //access-fine-location permission request
        if(requestCode == 1)
        {
            //check if user agreed
            if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
            {
            }

            return;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        //create options menu
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_options, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId())
        {
            case R.id.menu_send:    //clear db

                new AlertDialog.Builder(this)
                        .setTitle("")
                        .setMessage(SEND_ALERT_MESSAGE)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener()
                        {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                MainActivity.this.sendEmail();

                            }
                        })
                        .setNegativeButton("CANCEL", null)
                        .setIcon(android.R.drawable.sym_def_app_icon)
                        .show();

                break;
            case R.id.menu_save:    //save entries stored in internal data object to permanent sqlite db

                DBManager dbManager = new DBManager(MainActivity.this);
                dbManager.insertLogEntries(Global.getInstance().logEntryList);

                Global.getInstance().logEntryList.clear();
                break;
            case R.id.menu_profile: //go to profile page
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ProfileFragment()).commit();
                break;
        }

        return true;
    }

    @Override
    public void onBackPressed()     //back button press -> asks user if he wants to save data or not
    {
        new AlertDialog.Builder(this)
                .setTitle("")
                .setMessage(BACK_ALERT_MESSAGE)
                .setPositiveButton("OK", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //save
                        DBManager dbManager = new DBManager(MainActivity.this);
                        dbManager.insertLogEntries(Global.getInstance().logEntryList);

                        Global.getInstance().logEntryList.clear();

                        finish();
                    }
                })
                .setNegativeButton("NO", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //quit without saving
                        finish();
                    }
                })
                .setIcon(android.R.drawable.sym_def_app_icon)
                .show();

    }

    //send email , remove DB after sent
    public void sendEmail()
    {
        final MaterialDialog progressDialog  = new MaterialDialog.Builder(this)
                .title("Composing Email")
                .content("Please Wait...")
                .progress(true, 0)
                .show();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                //db manager
                DBManager dbManager = new DBManager(MainActivity.this);

                //compose email
                String mailBody = "User: " + Global.getInstance().user.userName + "\n\n";

                for(VehicleType vehicleType : VehicleType.values())
                {


                    ArrayList<LogEntry> list = dbManager.getAllLogEntries(vehicleType);

                    if (list.size() == 0)
                    {
                        continue;
                    }

                    String vehicleName = "";
                    switch(vehicleType.getValue())
                    {
                        case 0:
                            vehicleName = "CAR";
                            break;
                        case 4:
                            vehicleName = "ARTICULATED";
                            break;
                        case 1:
                            vehicleName = "TRUCK_5T";
                            break;
                        case 2:
                            vehicleName = "TRUCK_10T";
                            break;
                        case 3:
                            vehicleName = "TIPPER";
                            break;
                    }

                    mailBody+= "-- " + vehicleName + " --\n";

                    for(int index = 0 ; index < list.size(); index++)
                    {
                        LogEntry entry = list.get(index);
                        mailBody += "Driver: " + entry.driverName + " Rego: " + entry.rego + "\n" + entry.startTime + "\n" + entry.firstBreakTime + "\n" + entry.secondBreakTime + "\n" + entry.endTime + "\n\n";
                    }
                }

                String mailto = "mailto:" +
                        "?cc=" + "" +
                        "&subject=" + Uri.encode("New Logger Data") +
                        "&body=" + Uri.encode(mailBody);

                progressDialog.dismiss();

                Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                emailIntent.setData(Uri.parse(mailto));

                try {
                    startActivityForResult(emailIntent, 100);
                } catch (ActivityNotFoundException e) {
                    //TODO: Handle case where no email app is available
                }
            }
        }, 2000);



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 100)
        {
            //check email sent or not
            if(resultCode == RESULT_OK)
            {
                //clear db , goto home screen
                DBManager dbManager = new DBManager(MainActivity.this);
                dbManager.removeAllEntries();

                Global.getInstance().logEntryList.clear();

                Toast.makeText(this, "Email Sent, Database Cleared", Toast.LENGTH_SHORT).show();

                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
            }
            else
            {

            }
        }
    }
}
