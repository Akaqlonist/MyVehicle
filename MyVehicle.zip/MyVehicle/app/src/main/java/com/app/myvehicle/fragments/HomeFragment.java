package com.app.myvehicle.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.app.myvehicle.R;
import com.app.myvehicle.utils.VehicleType;

/**
 * Home screen fragment
 */

public class HomeFragment extends Fragment {

    //click listener for five buttons
    View.OnClickListener clickListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View view) {

            VehicleType type;

            switch(view.getId())
            {
                case R.id.button_car:
                    type = VehicleType.CAR;
                    break;
                case R.id.button_5t:
                    type = VehicleType.TRUCK_5T;
                    break;
                case R.id.button_10t:
                    type = VehicleType.TRUCK_10T;
                    break;
                case R.id.button_tipper:
                    type = VehicleType.TIPPER;
                    break;
                case R.id.button_articulated:
                    type = VehicleType.ARTICULATED;
                    break;
                default:
                    type = VehicleType.CAR;
                    break;
            }

            //show logentry screen
            LogEntryFragment fragment = new LogEntryFragment();
            fragment.setType(type);

            getFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).commit();
        }
    };


    public HomeFragment()
    {

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_home, container, false);


        //attach click listener to buttons
        ((Button)view.findViewById(R.id.button_car)).setOnClickListener(clickListener);

        ((Button)view.findViewById(R.id.button_5t)).setOnClickListener(clickListener);

        ((Button)view.findViewById(R.id.button_10t)).setOnClickListener(clickListener);

        ((Button)view.findViewById(R.id.button_tipper)).setOnClickListener(clickListener);

        ((Button)view.findViewById(R.id.button_articulated)).setOnClickListener(clickListener);

        return view;
    }
}
