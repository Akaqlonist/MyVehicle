package com.app.myvehicle.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.app.myvehicle.models.LogEntry;

import java.util.ArrayList;

/**
 * Created by DragonWarrior on 4/19/2017.
 */

public class DBManager extends SQLiteOpenHelper
{
    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "entrydatabase";

    // table name
    private static final String TABLE_NAME = "entrytable";

    // Contacts Table Columns names
    private static final String KEY_VEHICLETYPE = "type";
    private static final String KEY_DRIVER = "driver";
    private static final String KEY_REGO = "rego";
    private static final String KEY_STARTTIME = "starttime";
    private static final String KEY_FIRSTBREAKTIME = "firstbreaktime";
    private static final String KEY_SECONDBREAKTIME = "secondbreaktime";
    private static final String KEY_ENDTIME = "endtime";

    public DBManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_NAME + "("
                + KEY_VEHICLETYPE + " INTEGER," + KEY_DRIVER + " TEXT,"
                + KEY_REGO + " TEXT," +  KEY_STARTTIME + " TEXT," + KEY_FIRSTBREAKTIME + " TEXT," + KEY_SECONDBREAKTIME + " TEXT," + KEY_ENDTIME + " TEXT" +  ")";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);

        // Create tables again
        onCreate(db);
    }

    public void insertLogEntries(ArrayList<LogEntry> entryList)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        for(int index = 0 ; index < entryList.size(); index++)
        {
            LogEntry entry = entryList.get(index);

            ContentValues values = new ContentValues();
            values.put(KEY_VEHICLETYPE, entry.vehicleType.getValue());
            values.put(KEY_DRIVER, entry.driverName);
            values.put(KEY_REGO, entry.rego);
            values.put(KEY_STARTTIME, entry.startTime);
            values.put(KEY_FIRSTBREAKTIME, entry.firstBreakTime);
            values.put(KEY_SECONDBREAKTIME, entry.secondBreakTime);
            values.put(KEY_ENDTIME, entry.endTime);

            // Inserting Row
            db.insert(TABLE_NAME, null, values);
        }

        db.close(); // Closing database connection
    }

    public ArrayList<LogEntry> getAllLogEntries(VehicleType type)
    {
        ArrayList<LogEntry> entryList = new ArrayList<LogEntry>();

        int vehicleType = type.getValue();

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_NAME, new String[] { KEY_DRIVER,
                        KEY_REGO, KEY_STARTTIME, KEY_FIRSTBREAKTIME, KEY_SECONDBREAKTIME, KEY_ENDTIME },KEY_VEHICLETYPE + "=?",
                new String[] { String.valueOf(vehicleType) }, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                LogEntry entry = new LogEntry(type, cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5));

                // Adding entries to list
                entryList.add(entry);
            } while (cursor.moveToNext());
        }

        db.close();

        return entryList;
    }

    public void removeAllEntries()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, null, null);
        db.close();
    }
}

