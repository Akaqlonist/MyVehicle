package com.app.myvehicle.fragments;

import android.Manifest;
import android.content.pm.PackageManager;
import android.icu.text.SimpleDateFormat;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.app.myvehicle.R;
import com.app.myvehicle.models.LogEntry;
import com.app.myvehicle.utils.Global;
import com.app.myvehicle.utils.VehicleType;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;

import org.w3c.dom.Text;

import java.util.Date;

/**
 * LogEntry fragment where user can input log info
 */



public class LogEntryFragment extends Fragment
    implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener
{

    VehicleType type;
    String TITLE[] = {"Car", "5T Truck", "10T Truck", "Tipper", "Articulated"};
    String STRING_CANNOT_SAVE = "Entry not saved as not all data entered.\nComplete all entries and try again.";
    String STRING_SAVED = "Entry saved.";


    //google api client
    GoogleApiClient mGoogleApiClient;
    LocationRequest mLocationRequest;

    LatLng currentPosition = null;

    //get current timestamp
    public String getCurrentTime()
    {
        String timeStamp = new SimpleDateFormat("MM/dd/yyyy HH:mm").format(new Date());

        return timeStamp;
    }

    //save entered log info into internal object
    public void saveEntry()
    {
        String driverName = ((EditText)getView().findViewById(R.id.editDriver)).getText().toString();
        String rego = ((EditText)getView().findViewById(R.id.editRego)).getText().toString();
        String startTime = ((TextView)getView().findViewById(R.id.textview_starttime)).getText().toString();
        String firstBreakTime = ((TextView)getView().findViewById(R.id.textview_firstbreaktime)).getText().toString();
        String secondBreakTime = ((TextView)getView().findViewById(R.id.textview_secondbreaktime)).getText().toString();
        String endTime = ((TextView)getView().findViewById(R.id.textview_endtime)).getText().toString();

        LogEntry entry = new LogEntry(this.type, driverName, rego, startTime, firstBreakTime, secondBreakTime, endTime);

        Global.getInstance().logEntryList.add(entry);

        initView();
    }


    //click event listener for buttons
    View.OnClickListener clickListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View view) {

            switch(view.getId())
            {
                case R.id.button_previous:  //go to previous vehicle entry screen
                    if(type == VehicleType.CAR)
                        type = VehicleType.ARTICULATED;
                    else if(type == VehicleType.TRUCK_5T)
                        type = VehicleType.CAR;
                    else if(type == VehicleType.TRUCK_10T)
                        type = VehicleType.TRUCK_5T;
                    else if(type == VehicleType.TIPPER)
                        type = VehicleType.TRUCK_10T;
                    else type = VehicleType.TIPPER;

                    initView();

                    break;
                case R.id.button_next:  //go to next vehicle entry screen
                    if(type == VehicleType.CAR)
                        type = VehicleType.TRUCK_5T;
                    else if(type == VehicleType.TRUCK_5T)
                        type = VehicleType.TRUCK_10T;
                    else if(type == VehicleType.TRUCK_10T)
                        type = VehicleType.TIPPER;
                    else if(type == VehicleType.TIPPER)
                        type = VehicleType.ARTICULATED;
                    else type = VehicleType.CAR;

                    initView();
                    break;
                case R.id.button_home:  //go to home screen

                    getFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();

                    break;

                case R.id.button_savelog:   //save entry to internal object

                    if(((EditText)getView().findViewById(R.id.editDriver)).getText().toString().isEmpty() ||
                            ((EditText)getView().findViewById(R.id.editRego)).getText().toString().isEmpty() ||
                            ((TextView)getView().findViewById(R.id.textview_endtime)).getText().toString().isEmpty()
                            )
                    {
                        Toast.makeText(LogEntryFragment.this.getActivity(), STRING_CANNOT_SAVE, Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        saveEntry();

                        Toast.makeText(LogEntryFragment.this.getActivity(), STRING_SAVED, Toast.LENGTH_SHORT).show();
                    }

                    break;
                case R.id.button_showlog:   // go to logentry list

                    getFragmentManager().beginTransaction().replace(R.id.fragment_container, new LogListFragment(type)).addToBackStack(null).commit();

                    break;

                case R.id.button_starttime: //get current time and set

                    ((TextView)getView().findViewById(R.id.textview_starttime)).setText("Start:" + getCurrentTime() + " Longitude:" + currentPosition.longitude + " Latitude:" + currentPosition.latitude);
                    ((Button)getView().findViewById(R.id.button_starttime)).setVisibility(View.GONE);
                    ((Button)getView().findViewById(R.id.button_firstbreaktime)).setVisibility(View.VISIBLE);
                    break;

                case R.id.button_firstbreaktime:

                    ((TextView)getView().findViewById(R.id.textview_firstbreaktime)).setText("1st Break:" + getCurrentTime() + " Longitude:" + currentPosition.longitude + " Latitude:" + currentPosition.latitude);

                    ((Button)getView().findViewById(R.id.button_firstbreaktime)).setVisibility(View.GONE);
                    ((Button)getView().findViewById(R.id.button_secondbreaktime)).setVisibility(View.VISIBLE);
                    break;
                case R.id.button_secondbreaktime:

                    ((TextView)getView().findViewById(R.id.textview_secondbreaktime)).setText("2nd Break:" + getCurrentTime() + " Longitude:" + currentPosition.longitude + " Latitude:" + currentPosition.latitude);

                    ((Button)getView().findViewById(R.id.button_secondbreaktime)).setVisibility(View.GONE);
                    ((Button)getView().findViewById(R.id.button_endtime)).setVisibility(View.VISIBLE);

                    break;
                case R.id.button_endtime:

                    ((TextView)getView().findViewById(R.id.textview_endtime)).setText("End:" + getCurrentTime() + " Longitude:" + currentPosition.longitude + " Latitude:" + currentPosition.latitude);

                    ((Button)getView().findViewById(R.id.button_endtime)).setVisibility(View.GONE);

                    break;
            }
        }
    };

    public LogEntryFragment()
    {

    }

    public void setType(VehicleType type)
    {
        this.type = type;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_logentry, container, false);


        //attach event listener to buttons
        ((Button)view.findViewById(R.id.button_previous)).setOnClickListener(clickListener);
        ((Button)view.findViewById(R.id.button_next)).setOnClickListener(clickListener);
        ((Button)view.findViewById(R.id.button_home)).setOnClickListener(clickListener);

        ((Button)view.findViewById(R.id.button_savelog)).setOnClickListener(clickListener);
        ((Button)view.findViewById(R.id.button_showlog)).setOnClickListener(clickListener);

        ((Button)view.findViewById(R.id.button_starttime)).setOnClickListener(clickListener);
        ((Button)view.findViewById(R.id.button_firstbreaktime)).setOnClickListener(clickListener);
        ((Button)view.findViewById(R.id.button_secondbreaktime)).setOnClickListener(clickListener);
        ((Button)view.findViewById(R.id.button_endtime)).setOnClickListener(clickListener);

        //set title
        ((TextView)view.findViewById(R.id.textview_title)).setText(TITLE[type.getValue()]);

        //start updating location
        buildGoogleApiClient();
        createLocationRequest();

        return view;
    }

    public void buildGoogleApiClient()
    {
        mGoogleApiClient = new GoogleApiClient.Builder(this.getContext())
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
    }

    protected void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(5000);
        mLocationRequest.setFastestInterval(1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    public void initView()  //set visibility of buttons & textview - initial state
    {
        ((TextView)this.getView().findViewById(R.id.textview_title)).setText(TITLE[type.getValue()]);

        ((EditText)getView().findViewById(R.id.editDriver)).setText("");
        ((EditText)getView().findViewById(R.id.editRego)).setText("");

        ((Button)getView().findViewById(R.id.button_starttime)).setVisibility(View.VISIBLE);
        ((Button)getView().findViewById(R.id.button_firstbreaktime)).setVisibility(View.INVISIBLE);
        ((Button)getView().findViewById(R.id.button_secondbreaktime)).setVisibility(View.INVISIBLE);
        ((Button)getView().findViewById(R.id.button_endtime)).setVisibility(View.INVISIBLE);

        ((TextView)getView().findViewById(R.id.textview_starttime)).setText("");
        ((TextView)getView().findViewById(R.id.textview_firstbreaktime)).setText("");
        ((TextView)getView().findViewById(R.id.textview_secondbreaktime)).setText("");
        ((TextView)getView().findViewById(R.id.textview_endtime)).setText("");
    }


    //callbacks for google api , location request
    @Override
    public void onStart() {
        super.onStart();
        mGoogleApiClient.connect();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mGoogleApiClient.isConnected()) {
            startLocationUpdates();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if(mGoogleApiClient.isConnected()) {
            stopLocationUpdates();
        }
    }

    @Override
    public void onConnected(Bundle bundle) {

            if (ActivityCompat.checkSelfPermission(this.getContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                Location location = LocationServices.FusedLocationApi.getLastLocation(
                        mGoogleApiClient);
                if (location != null) {
                    currentPosition = new LatLng(location.getLatitude(), location.getLongitude());
                }
            }
        startLocationUpdates();
    }

    @Override
    public void onConnectionSuspended(int i) {
        stopLocationUpdates();
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {

    }

    protected void startLocationUpdates() {
        if(ActivityCompat.checkSelfPermission(this.getContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        }
    }

    protected void stopLocationUpdates() {
        LocationServices.FusedLocationApi.removeLocationUpdates(
                mGoogleApiClient, this);
    }

    @Override
    public void onLocationChanged(Location location) {

        currentPosition = new LatLng(location.getLatitude(), location.getLongitude());

    }

    @Override
    public void onStop() {
        super.onStop();
        if (mGoogleApiClient.isConnected())
            mGoogleApiClient.disconnect();
    }

}
