package com.app.myvehicle.models;

/**
 * Data model for user profile info
 */

public class User {

    public String userName;
    public String password;

    public User(String userName, String password)
    {
        this.userName = userName;
        this.password = password;
    }
}
