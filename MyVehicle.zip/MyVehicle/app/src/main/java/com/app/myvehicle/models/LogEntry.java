package com.app.myvehicle.models;

import com.app.myvehicle.utils.VehicleType;

/**
 * Data model for log entry info
 */

public class LogEntry {

    public VehicleType vehicleType;
    public String driverName;
    public String rego;
    public String startTime;
    public String firstBreakTime;
    public String secondBreakTime;
    public String endTime;

    public LogEntry(VehicleType vehicleType, String driverName, String rego, String startTime, String firstBreakTime, String secondBreakTime, String endTime)
    {
        this.vehicleType = vehicleType;
        this.driverName = driverName;
        this.rego = rego;
        this.startTime = startTime;
        this.firstBreakTime = firstBreakTime;
        this.secondBreakTime = secondBreakTime;
        this.endTime = endTime;
    }

}
