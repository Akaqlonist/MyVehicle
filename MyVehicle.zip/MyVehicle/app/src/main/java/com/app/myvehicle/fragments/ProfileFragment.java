package com.app.myvehicle.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.app.myvehicle.R;
import com.app.myvehicle.utils.Global;

/**
 * Profile fragment , let the user set up his/her profile & save them
 */

public class ProfileFragment extends Fragment {

    private String STRING_CANNOT_SAVE = "Input is not correct , cannot save profile!";
    private String STRING_PROFILE_SAVED = "Profile saved.";

    public ProfileFragment()
    {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    //button click listener
    View.OnClickListener clickListener = new View.OnClickListener()
    {
        @Override
        public void onClick(View view) {

            switch(view.getId())
            {
                case R.id.button_saveprofile:   //save profile info to global variable
                    String userName = ((EditText)getView().findViewById(R.id.editUsername)).getText().toString();
                    String password = ((EditText)getView().findViewById(R.id.editPassword)).getText().toString();
                    String repeatPassword = ((EditText)getView().findViewById(R.id.editRepeatPassword)).getText().toString();

                    if(userName.isEmpty() || password.isEmpty() || repeatPassword.isEmpty() || !password.equals(repeatPassword))
                    {
                        Toast.makeText(getActivity(), STRING_CANNOT_SAVE, Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Global.getInstance().user.userName = userName;
                        Global.getInstance().user.password = password;

                        //save in preference
                        SharedPreferences preferences = getActivity().getPreferences(Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putString("username", userName);
                        editor.putString("password", password);
                        editor.commit();

                        Toast.makeText(getActivity(), STRING_PROFILE_SAVED, Toast.LENGTH_SHORT).show();
                        getFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
                    }

                    break;
                case R.id.button_cancelprofile: //cancel setting up
                    getFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
                    break;
            }


        }

    };

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        //init views
        ((Button)view.findViewById(R.id.button_saveprofile)).setOnClickListener(clickListener);
        ((Button)view.findViewById(R.id.button_cancelprofile)).setOnClickListener(clickListener);

        //load preference
        SharedPreferences preferences = getActivity().getPreferences(Context.MODE_PRIVATE);
        String name = preferences.getString("username", "");
        String password = preferences.getString("password", "");

        Global.getInstance().user.userName = name;
        Global.getInstance().user.password = password;

        ((EditText)view.findViewById(R.id.editUsername)).setText(Global.getInstance().user.userName);
        ((EditText)view.findViewById(R.id.editPassword)).setText(Global.getInstance().user.password);





        return view;
    }
}
