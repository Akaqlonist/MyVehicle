package com.app.myvehicle.utils;

/**
 * Created by DragonWarrior on 4/18/2017.
 */

public enum VehicleType
{
    CAR(0),
    TRUCK_5T(1),
    TRUCK_10T(2),
    TIPPER(3),
    ARTICULATED(4);

    private int value;

    private VehicleType(int value)
    {
        this.value = value;
    }

    public int getValue()
    {
        return this.value;
    }

}
