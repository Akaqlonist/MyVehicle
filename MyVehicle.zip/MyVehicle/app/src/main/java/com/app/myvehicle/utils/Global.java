package com.app.myvehicle.utils;

import com.app.myvehicle.models.LogEntry;
import com.app.myvehicle.models.User;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by DragonWarrior on 4/19/2017.
 */
public class Global {

    private static Global ourInstance = new Global();

    public static Global getInstance() {
        return ourInstance;
    }

    private Global() {


    }

    public ArrayList<LogEntry> logEntryList = new ArrayList<LogEntry>();

    public User user = new User("", "");

}
